
public class SMBDetail {
	
}
